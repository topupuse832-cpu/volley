package com.example.volleyapi;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class GetremotedataActivity extends AppCompatActivity {

    TextView txtresult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_getremotedata);
        txtresult=findViewById(R.id.remotedata);

        volleyRequest();

    }
    public void volleyRequest()
    {
        String url="http://10.0.2.2/Encodejson/getdata.php";
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                decodeJson(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Log.d("Error",volleyError.toString());
            }
        }

        );
        queue.add(stringRequest);

    }
    private void decodeJson(String response){

        try{
            JSONObject obj = new JSONObject(response);
            JSONArray array = obj.getJSONArray("data");
            String displaydata="Data from remote server\nRoll\t\t\t\t\tName\t\t\t\t\tSemester\n";
            for(int i=0;i<array.length();i++){
                JSONObject st = array.getJSONObject(i);
                int roll=st.getInt("Roll");
                String name=st.getString("Name");
                String sem=st.getString("Semester");

                displaydata+=+roll+"\t\t\t\t\t\t\t" +name+ "\t\t\t\t\t\t\t"+sem+"\n";





            }
            txtresult.setText(displaydata);

        }catch (Exception e){
        }
    }
}
