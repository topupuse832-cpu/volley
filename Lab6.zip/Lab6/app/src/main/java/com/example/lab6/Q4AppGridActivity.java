package com.example.lab6;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

public class Q4AppGridActivity extends AppCompatActivity {

    GridView grid;

    String[] names = {"YouTube", "Facebook", "Twitter", "Instagram"};
    int[] logos = {R.drawable.youtube, R.drawable.facebook, R.drawable.twitter, R.drawable.instagram};
    String[] urls = {
            "https://www.youtube.com",
            "https://www.facebook.com",
            "https://www.twitter.com",
            "https://www.instagram.com"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q4_app_grid);

        grid = findViewById(R.id.appGrid);

        Q4AppAdapter adapter = new Q4AppAdapter(this, logos, names);
        grid.setAdapter(adapter);

        grid.setOnItemClickListener((parent, view, position, id) -> {

            Intent intent = new Intent(Q4AppGridActivity.this, Q4AppWebActivity.class);
            intent.putExtra("url", urls[position]);
            startActivity(intent);
        });
    }
}
