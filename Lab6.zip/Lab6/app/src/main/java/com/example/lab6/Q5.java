package com.example.lab6;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Q5 extends AppCompatActivity {

    RecyclerView recyclerView;
    Q5EmployeeAdapter adapter;
    ArrayList<Employee> employeeList;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q5);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Sample employee data
        employeeList = new ArrayList<>();
        employeeList.add(new Employee("E001", "Sujan ", "Kathmandu", 50000));
        employeeList.add(new Employee("E002", "Anita ", "Lalitpur", 55000));
        employeeList.add(new Employee("E003", "Ramesh ", "Pokhara", 52000));
        employeeList.add(new Employee("E004", "Sita ", "Biratnagar", 58000));
        employeeList.add(new Employee("E005", "Binod ", "Dharan", 60000));


        adapter = new Q5EmployeeAdapter(this, employeeList);
        recyclerView.setAdapter(adapter);
    }
}
