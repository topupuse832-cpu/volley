package com.example.lab6;

public class Student {
    private String roll;
    private String name;
    private String address;

    public Student(String roll, String name, String address) {
        this.roll = roll;
        this.name = name;
        this.address = address;
    }

    public String getRoll() { return roll; }
    public String getName() { return name; }
    public String getAddress() { return address; }
}
