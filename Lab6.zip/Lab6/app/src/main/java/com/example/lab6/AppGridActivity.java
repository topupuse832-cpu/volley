package com.example.lab6;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

public class AppGridActivity extends AppCompatActivity {

    GridView grid;

    String[] names = {"YouTube", "Facebook", "Twitter", "Instagram"};
    int[] logos = {R.drawable.youtube, R.drawable.facebook, R.drawable.twitter, R.drawable.instagram};
    String[] urls = {
            "https://www.youtube.com",
            "https://www.facebook.com",
            "https://www.twitter.com",
            "https://www.instagram.com"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_grid);

        grid = findViewById(R.id.appGrid);

        String[] appNames = {"YouTube", "Facebook", "Twitter", "Instagram"};
        int[] appLogos = {R.drawable.youtube, R.drawable.facebook, R.drawable.twitter, R.drawable.instagram};
        String[] appUrls = {
                "https://www.youtube.com",
                "https://www.facebook.com",
                "https://www.twitter.com",
                "https://www.instagram.com"
        };

        AppAdapter adapter = new AppAdapter(this, appLogos, appNames);
        grid.setAdapter(adapter);

        grid.setOnItemClickListener((parent, view, position, id) -> {
            String url = appUrls[position]; // dynamically select URL
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            startActivity(intent);
        });
    }
}
