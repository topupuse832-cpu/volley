package com.example.lab6;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

public class GridAdapter extends ArrayAdapter<String> {

    Activity context;
    int[] images;
    String[] names;

    public GridAdapter(Activity context, int[] images, String[] names) {
        super(context, R.layout.customlist, names);
        this.context = context;
        this.images = images;
        this.names = names;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.customlist, parent, false);

        ImageView img = view.findViewById(R.id.image);
        img.setImageResource(images[position]);

        return view;
    }

    public String getItemName(int position) {
        return names[position];
    }
}
