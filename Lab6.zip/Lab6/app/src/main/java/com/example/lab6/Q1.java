package com.example.lab6;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class Q1 extends AppCompatActivity {

    ListView list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1);
        list = findViewById(R.id.list);
        String[] courses = {"Advanced Java", "Network Programming", "Distributed system", "Mobile Programming", "Applied Economics", "Database Management", "C Programming", "Java Programming", "Dotnet Technology", "Operating System"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.activity_q1, courses);
        list.setAdapter(adapter);
    }
}