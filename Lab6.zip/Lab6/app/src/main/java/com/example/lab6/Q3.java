package com.example.lab6;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Q3 extends AppCompatActivity {

    GridView grid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_q3);

        grid = findViewById(R.id.customgrid);

        int[] images = {
                R.drawable.img, R.drawable.img_1, R.drawable.img_2,
                R.drawable.img_3, R.drawable.img_4, R.drawable.img_5,
                R.drawable.img_6, R.drawable.img_7, R.drawable.img_8,
                R.drawable.img_9
        };

        String[] names = {
                "Apple", "Banana", "Mango", "Orange",
                "Blueberry", "Grapes", "Pineapple",
                "Watermelon", "Pomegranate", "Kiwi"
        };

        Q3GridAdapter adapter = new Q3GridAdapter(this, images, names);
        grid.setAdapter(adapter);

        grid.setOnItemClickListener((parent, view, position, id) -> {
            String fruitName = adapter.getItemName(position);
            Toast.makeText(Q3.this, "You clicked: " + fruitName, Toast.LENGTH_SHORT).show();
        });
    }
}
