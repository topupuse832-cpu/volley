package com.example.lab6;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Q4AppAdapter extends ArrayAdapter<String> {

    Activity context;
    int[] logos;
    String[] names;

    public Q4AppAdapter(Activity context, int[] logos, String[] names) {
        super(context, R.layout.q4_item_app, names);
        this.context = context;
        this.logos = logos;
        this.names = names;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.q4_item_app, parent, false);

        ImageView img = view.findViewById(R.id.image);
        TextView txt = view.findViewById(R.id.txtname);

        img.setImageResource(logos[position]);
        txt.setText(names[position]);

        return view;
    }
}
