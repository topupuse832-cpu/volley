package com.example.lab6;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Q5EmployeeAdapter extends RecyclerView.Adapter<Q5EmployeeAdapter.ViewHolder> {

    Activity context;
    List<Employee> employees;

    public Q5EmployeeAdapter(Activity context, List<Employee> employees) {
        this.context = context;
        this.employees = employees;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.q5_item_employee, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Employee emp = employees.get(position);
        holder.tvId.setText("ID: " + emp.getId());
        holder.tvName.setText("Name: " + emp.getName());
        holder.tvAddress.setText("Address: " + emp.getAddress());
        holder.tvSalary.setText("Salary: $" + emp.getSalary());
    }

    @Override
    public int getItemCount() {
        return employees.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvId, tvName, tvAddress, tvSalary;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvId);
            tvName = itemView.findViewById(R.id.tvName);
            tvAddress = itemView.findViewById(R.id.tvAddress);
            tvSalary = itemView.findViewById(R.id.tvSalary);
        }
    }
}
