package com.example.lab6;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Q2 extends AppCompatActivity {

    ListView listView;
    ArrayList<Student> studentList;
    ArrayList<String> studentNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q2);

        listView = findViewById(R.id.listViewStudents);

        // Sample data
        studentList = new ArrayList<>();
        studentList.add(new Student("S001", "Sujan", "Kathmandu"));
        studentList.add(new Student("S002", "Anita", "Lalitpur"));
        studentList.add(new Student("S003", "Ramesh", "Pokhara"));
        studentList.add(new Student("S004", "Sita", "Biratnagar"));
        studentList.add(new Student("S005", "Binod", "Dharan"));


        // Extract names for ListView
        studentNames = new ArrayList<>();
        for (Student s : studentList) {
            studentNames.add(s.getName());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, studentNames);
        listView.setAdapter(adapter);

        // Item click listener
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Student selectedStudent = studentList.get(position);
            showStudentDialog(selectedStudent);
        });
    }

    private void showStudentDialog(Student student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.q2_dialog_student, null);

        TextView tvRoll = dialogView.findViewById(R.id.tvRoll);
        TextView tvName = dialogView.findViewById(R.id.tvName);
        TextView tvAddress = dialogView.findViewById(R.id.tvAddress);

        tvRoll.setText("Roll: " + student.getRoll());
        tvName.setText("Name: " + student.getName());
        tvAddress.setText("Address: " + student.getAddress());

        builder.setView(dialogView);
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}
